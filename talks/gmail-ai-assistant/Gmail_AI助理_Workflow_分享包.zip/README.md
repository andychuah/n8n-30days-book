# Gmail AI 助理｜Workflow 分享包

這個 n8n workflow 會監看新郵件，請 Gemini 判斷郵件類型，再由 n8n 貼上 Gmail 標籤。只有確實需要回覆的郵件，才會建立一封**未寄出的 Gmail 草稿**。

## 分享包內容

- `gmail_ai_assistant_workflow.json`：主 workflow
- `optional_demo_sender.json`：可選的測試寄信 workflow
- `README.md`：設定、測試與安全界線

## 第一次設定

1. 在 n8n 匯入 `gmail_ai_assistant_workflow.json`，先不要 Publish。
2. 為所有 Gmail 節點綁定你自己的 Gmail OAuth2 credential。
3. 為 Gemini 節點綁定你自己的 Google Gemini credential。
4. 執行一次「一次性：建立 Demo 標籤」支線，建立：
   - `01_待回覆`
   - `02_會議`
   - `03_FYI`
   - `04_通知`
   - `05_行銷`
5. 從另一個測試信箱寄幾封測試信，確認分類與草稿符合自己的習慣。
6. 確認無誤後，再考慮 Publish 主流程。

若五個標籤已經存在，不要重複執行設定支線。

## 建議測試信

### 會議＋需要回覆

**主旨：** 週五會議可以改到三點嗎？

**內容：**

> 嗨，因為上午臨時有安排，想問週五的會議是否方便改到下午三點？謝謝！

預期：`02_會議`、`needsReply: true`、建立草稿。

### 系統通知＋不回覆

**主旨：** 今晚 VPN 維護通知

**內容：**

> 今晚 10 點至 11 點進行例行維護，期間 VPN 可能短暫中斷。本信為系統通知，請勿回覆。

預期：`04_通知`、`needsReply: false`、不建立草稿。

### 行銷＋不回覆

**主旨：** 夏季方案限時七折

**內容：**

> 本週完成訂閱可享七折優惠，點擊連結了解詳情。

預期：`05_行銷`、`needsReply: false`、不建立草稿。

## 安全界線

- 主流程只使用 Gmail `Create a draft`，沒有連接 `Send a message`。
- 不自動刪除郵件。
- 不替使用者承諾價格、折扣、批准或時程。
- 資訊不足時，草稿應表達「先確認後回覆」，不可自行補資料。
- `FYI`、`通知`、`行銷` 與 no-reply 郵件不建立草稿。
- 先用五到十封測試信驗證，再慢慢擴大範圍。

## Credential 與隱私

分享 JSON 不包含 API key、OAuth token、密碼或講者帳號。匯入後必須改綁你自己的 credential。

